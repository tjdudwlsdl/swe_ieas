var service = new 
tizen.ApplicationControl("http://tizen.org/appcontrol/operation/push_test");

function errorCallback(response){
	console.log('The following error occured: '+response.name);
}

function registerSuccessCallback(id){
	console.log('Registration succeeded with id: '+id);
}

tizen.push.registerService(service, registerSuccessCallback, errorCallback);



window.onload = function() {
    // TODO:: Do your initialization job

    // add eventListener for tizenhwkey
    document.addEventListener('tizenhwkey', function(e) {
        if (e.keyName === "back") {
            try {
                tizen.application.getCurrentApplication().exit();
            } catch (ignore) {}
        }
    });
    

    function notificationCallback(noti)
    {
       console.log("Notification received with alert message: " + noti.alertMessage);
    }

    tizen.push.connectService(notificationCallback, errorCallback);
    
    // Sample code
    var mainPage = document.querySelector('#main');

    mainPage.addEventListener("click", function() {
        var contentText = document.querySelector('#content-text');

        contentText.innerHTML = (contentText.innerHTML === "Basic") ? "Tizen" : "Basic";
    });
};